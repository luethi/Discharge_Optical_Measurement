# -*- coding: utf-8 -*-
"""
Created on Mon Oct 19 18:41:28 2015
@author: sp


Reads DXF file created by the disto, and plots the markers

Data from the disto:
- 2DG --> this is the floor plan (view from the top)
- 2DW --> this is the front view. This file will only be created if between 
  first and second measurement the horizontal movement was at least 10cm. 
  Otherwise no horizontal axis can be defined for presentation.
- 3D --> this is the 3D drawing


The first measured point is the reference for the drawing. 
The second point defines the x-axis. 
The y-axis and z-axis are rectangular to it also referenced to the horizontal plane (levelling).
An exception to this would be if the horizontal distance between the first and second measured
point is less than 10cm. In such case the DISTO™ will be the reference in the drawing 
and the direction to the first measured point will be the x-axis.
"""


import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import os
path = os.path.dirname(os.path.abspath(__file__)) # get current path


##########################################################################################

# - Disto file: -
file_name = path + '/disto.dxf'

##########################################################################################


# --- read dxf file and get coordinates ---
# -get indicators where points are located -
count = 0
ind_points = []
with open(file_name, 'r') as f:
    for line in f:
        count = count + 1
        if "AcDbPoint" in line:
             a = line
             ind_points.append(count)

# - get the data -
x = []
y = []
z = []

for p in range(0, len(ind_points)):
    fp = open(file_name)
    for i, line in enumerate(fp):
        if i == ind_points[p] + 1: # X
            #print "X_%i=%s" %(p, line)
            print line
            x.append(float(line))
        if i == ind_points[p] + 3: # Y
            #print "Y_%i=%s" %(p, line)
            print line
            y.append(float(line))
        if i == ind_points[p] + 5: # Z
            #print "Z_%i=%s" %(p, line)
            print line
            z.append(float(line))
    fp.close()


# --- save makers coordinates into txt file ---
output_file = path + '/disto.txt'
with open(output_file, "w") as myfile:
    for num in range(len(x)):    
            myfile.write(str(x[num]) + '\t' +  str(y[num]) + '\t' + str(z[num]))
            myfile.write('\n')


# --- plot ---
plt3d = plt.figure('3D view', figsize=(15, 5)).gca(projection='3d') 
plt3d.scatter(x, y, z, marker='x', color='black', label="markers")
plt3d.set_xlabel("X (m)")
plt3d.set_ylabel("Y (m)")
plt3d.set_zlabel("Z (m)")
plt3d.set_title(file_name)
#plt3d.axis('equal')     
plt.show('3D view')






